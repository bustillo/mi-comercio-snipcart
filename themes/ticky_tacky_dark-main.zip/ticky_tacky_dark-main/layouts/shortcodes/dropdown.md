<details>
    <summary>{{ .Get "summary" }}</summary>
    {{ .Inner | markdownify }}
</details>
